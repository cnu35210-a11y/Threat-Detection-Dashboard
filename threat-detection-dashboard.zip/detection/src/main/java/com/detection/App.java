package com.detection;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.util.Objects;

/**
 * Punto de entrada de la aplicacion "Threat Detection Dashboard (Mini-SIEM)".
 * <p>
 * Esta clase se limita a responsabilidades de arranque (bootstrap): cargar el
 * FXML de la vista principal, aplicar la hoja de estilos del tema oscuro y
 * mostrar la ventana. Toda la logica de negocio vive en los paquetes
 * {@code model}, {@code service} y {@code controller}.
 */
public class App extends Application {

    private static final String MAIN_VIEW_FXML = "/com/detection/main.fxml";
    private static final String DARK_THEME_CSS = "/com/detection/dark-theme.css";

    @Override
    public void start(Stage primaryStage) throws Exception {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(MAIN_VIEW_FXML));
        Parent root = loader.load();

        Scene scene = new Scene(root, 1440, 860);
        scene.getStylesheets().add(
                Objects.requireNonNull(getClass().getResource(DARK_THEME_CSS)).toExternalForm());

        primaryStage.setTitle("Threat Detection Dashboard - Mini SIEM | SOC Console");
        primaryStage.setScene(scene);
        primaryStage.setMinWidth(1150);
        primaryStage.setMinHeight(680);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
