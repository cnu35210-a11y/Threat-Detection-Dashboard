package com.detection;

/**
 * Punto de arranque alternativo que NO extiende {@code javafx.application.Application}.
 * <p>
 * Cuando una clase que extiende {@code Application} se ejecuta directamente
 * (por ejemplo con el boton "Run" de VS Code, IntelliJ, o {@code java -cp ...
 * com.detection.App}), el lanzador de Java detecta ese patron mediante
 * reflexion y aborta con el error:
 * <pre>
 * Error: JavaFX runtime components are missing, and are required to run this application
 * </pre>
 * incluso si javafx-controls/javafx-graphics/javafx-fxml SI estan en el
 * classpath. Esto ocurre porque, fuera de {@code mvn javafx:run} (que arma un
 * module-path correcto automaticamente), Java exige que quien invoque
 * {@code Application.launch(...)} sea una clase "normal" y no la propia
 * subclase de {@code Application}.
 * <p>
 * La solucion estandar es indirectar el arranque a traves de esta clase.
 * Es el {@code mainClass} recomendado para ejecutar el proyecto desde un IDE
 * o con {@code java -cp ...}; para {@code mvn javafx:run} tambien funciona
 * sin cambios.
 */
public final class Launcher {

    private Launcher() {
    }

    public static void main(String[] args) {
        App.main(args);
    }
}
