package com.detection.controller;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;

/**
 * Controller del panel inferior: consola de eventos SOAR y barra de estado.
 * Componente de salida pura, sin logica de negocio.
 */
public class ConsolePanelController {

    @FXML private TextArea soarConsoleArea;
    @FXML private Label statusBarLabel;

    public void appendLine(String line) {
        soarConsoleArea.appendText(line + System.lineSeparator());
    }

    public void setStatus(String message) {
        statusBarLabel.setText(message);
    }
}
