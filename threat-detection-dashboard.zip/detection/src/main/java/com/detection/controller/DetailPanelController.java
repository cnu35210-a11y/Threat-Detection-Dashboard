package com.detection.controller;

import com.detection.model.LogEntry;
import com.detection.model.Severity;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;

import java.util.function.Consumer;

/**
 * Controller del panel de detalle (log crudo + ficha MITRE ATT&amp;CK +
 * accion de contencion).
 * <p>
 * No ejecuta el playbook por si mismo: al pulsar el boton, delega en el
 * callback registrado por {@link MainController} via
 * {@link #setOnPlaybookRequested(Consumer)}, que es quien conoce el
 * {@code SoarService}, la consola y como refrescar el resto de la UI.
 */
public class DetailPanelController {

    @FXML private TextArea rawLogTextArea;
    @FXML private Label mitreIdLabel;
    @FXML private Label mitreTechniqueLabel;
    @FXML private TextArea mitreDescriptionArea;
    @FXML private Label ruleMatchedDetailLabel;
    @FXML private Label statusDetailLabel;
    @FXML private Button playbookButton;

    private LogEntry currentEntry;
    private Consumer<LogEntry> onPlaybookRequested;

    @FXML
    public void initialize() {
        showEmpty();
    }

    public void setOnPlaybookRequested(Consumer<LogEntry> handler) {
        this.onPlaybookRequested = handler;
    }

    public void showDetail(LogEntry entry) {
        this.currentEntry = entry;
        if (entry == null) {
            showEmpty();
            return;
        }
        rawLogTextArea.setText(entry.getRawLog());
        mitreIdLabel.setText(entry.getMitreId());
        mitreTechniqueLabel.setText(entry.getMitreTechnique());
        mitreDescriptionArea.setText(entry.getMitreDescription());
        ruleMatchedDetailLabel.setText(entry.getRuleMatched());
        statusDetailLabel.setText(entry.getStatus());

        statusDetailLabel.getStyleClass().removeAll("status-new", "status-contained");
        statusDetailLabel.getStyleClass().add("CONTAINED".equals(entry.getStatus()) ? "status-contained" : "status-new");

        boolean canRunPlaybook = entry.getSeverity() == Severity.HIGH && !"CONTAINED".equals(entry.getStatus());
        playbookButton.setDisable(!canRunPlaybook);
    }

    public void showEmpty() {
        this.currentEntry = null;
        rawLogTextArea.setText("Selecciona un evento de la tabla para ver el log crudo (JSON).");
        mitreIdLabel.setText("-");
        mitreTechniqueLabel.setText("-");
        mitreDescriptionArea.setText("Sin evento seleccionado.");
        ruleMatchedDetailLabel.setText("-");
        statusDetailLabel.setText("-");
        playbookButton.setDisable(true);
    }

    @FXML
    private void handlePlaybookButton() {
        if (currentEntry != null && onPlaybookRequested != null) {
            onPlaybookRequested.accept(currentEntry);
        }
    }
}
