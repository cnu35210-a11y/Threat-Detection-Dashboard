package com.detection.controller;

import com.detection.model.LogEntry;
import com.detection.model.Severity;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * Controller de la tabla principal de eventos/alertas.
 * <p>
 * Responsabilidad unica: renderizar el {@link LogEntry#toString() listado},
 * aplicar filtros de severidad/busqueda mediante {@link FilteredList} y
 * exponer la seleccion actual. No conoce servicios de negocio: recibe la
 * lista maestra ya calculada desde {@link MainController}.
 */
public class LogsTableController {

    @FXML private TableView<LogEntry> logsTable;
    @FXML private TableColumn<LogEntry, String> colTimestamp;
    @FXML private TableColumn<LogEntry, String> colSourceIp;
    @FXML private TableColumn<LogEntry, String> colDestIp;
    @FXML private TableColumn<LogEntry, String> colEventType;
    @FXML private TableColumn<LogEntry, String> colRuleMatched;
    @FXML private TableColumn<LogEntry, Severity> colSeverity;
    @FXML private TableColumn<LogEntry, String> colStatus;

    private FilteredList<LogEntry> filteredData;

    @FXML
    public void initialize() {
        configureColumns();
        configureRowColoring();
    }

    /** Conecta la lista observable maestra (mutable) con la tabla, envolviendola en Filtered/Sorted. */
    public void setMasterData(ObservableList<LogEntry> masterData) {
        filteredData = new FilteredList<>(masterData, entry -> true);
        SortedList<LogEntry> sortedData = new SortedList<>(filteredData);
        sortedData.comparatorProperty().bind(logsTable.comparatorProperty());
        logsTable.setItems(sortedData);
    }

    /** Aplica de forma combinada el filtro de severidad y el texto de busqueda libre. */
    public void applyFilters(String searchQuery, String severityChoice) {
        if (filteredData == null) {
            return;
        }
        String query = searchQuery == null ? "" : searchQuery.trim().toLowerCase();

        filteredData.setPredicate(entry -> {
            boolean matchesSeverity = severityChoice == null || severityChoice.equals("TODAS")
                    || entry.getSeverity().name().equalsIgnoreCase(severityChoice);
            if (!matchesSeverity) {
                return false;
            }
            if (query.isEmpty()) {
                return true;
            }
            return containsIgnoreCase(entry.getSourceIp(), query)
                    || containsIgnoreCase(entry.getDestinationIp(), query)
                    || containsIgnoreCase(entry.getEventType(), query)
                    || containsIgnoreCase(entry.getUser(), query)
                    || containsIgnoreCase(entry.getRuleMatched(), query)
                    || containsIgnoreCase(entry.getMessage(), query);
        });
    }

    public ReadOnlyObjectProperty<LogEntry> selectedItemProperty() {
        return logsTable.getSelectionModel().selectedItemProperty();
    }

    /** Fuerza el repintado de filas (usado tras cambios de estado que no disparan binding, ej. CONTAINED). */
    public void refresh() {
        logsTable.refresh();
    }

    /** Expone la ventana propietaria de la tabla, util para abrir dialogos (FileChooser, Alert) desde el mediador. */
    public javafx.stage.Window getWindow() {
        return logsTable.getScene() != null ? logsTable.getScene().getWindow() : null;
    }

    // ------------------------------------------------------------------ setup

    private void configureColumns() {
        colTimestamp.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getFormattedTimestamp()));
        colSourceIp.setCellValueFactory(new PropertyValueFactory<>("sourceIp"));
        colDestIp.setCellValueFactory(new PropertyValueFactory<>("destinationIp"));
        colEventType.setCellValueFactory(new PropertyValueFactory<>("eventType"));
        colRuleMatched.setCellValueFactory(new PropertyValueFactory<>("ruleMatched"));
        colStatus.setCellValueFactory(new PropertyValueFactory<>("status"));

        colSeverity.setCellValueFactory(new PropertyValueFactory<>("severity"));
        colSeverity.setCellFactory(column -> new TableCell<>() {
            @Override
            protected void updateItem(Severity severity, boolean empty) {
                super.updateItem(severity, empty);
                getStyleClass().removeAll("badge-high", "badge-medium", "badge-low", "badge-info");
                if (empty || severity == null) {
                    setText(null);
                } else {
                    setText(severity.getLabel().toUpperCase());
                    getStyleClass().add("badge-" + severity.name().toLowerCase());
                }
            }
        });
    }

    private void configureRowColoring() {
        logsTable.setRowFactory(tv -> new TableRow<LogEntry>() {
            @Override
            protected void updateItem(LogEntry item, boolean empty) {
                super.updateItem(item, empty);
                getStyleClass().removeAll("row-high", "row-medium", "row-low");
                if (!empty && item != null && item.getSeverity() != null) {
                    switch (item.getSeverity()) {
                        case HIGH -> getStyleClass().add("row-high");
                        case MEDIUM -> getStyleClass().add("row-medium");
                        case LOW -> getStyleClass().add("row-low");
                        default -> { /* sin estilo especial para INFO */ }
                    }
                }
            }
        });
    }

    private boolean containsIgnoreCase(String value, String query) {
        return value != null && value.toLowerCase().contains(query);
    }
}
