package com.detection.controller;

import com.detection.model.LogEntry;
import com.detection.model.Severity;
import com.detection.service.DetectionEngine;
import com.detection.service.LogIngestionService;
import com.detection.service.MockLogGenerator;
import com.detection.service.SoarService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.stage.FileChooser;
import javafx.stage.Window;

import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 * Controller raiz / mediador de la vista principal (patron Mediator).
 * <p>
 * {@code main.fxml} se compone de cinco fragmentos independientes
 * (toolbar, panel de metricas, tabla, panel de detalle y consola SOAR), cada
 * uno con su propio controller y su propia responsabilidad unica. Esta clase
 * NO dibuja nada por si misma: su unico trabajo es (1) mantener el estado
 * compartido (la lista maestra de logs) y los servicios de negocio, y
 * (2) conectar las señales de un sub-controller con las acciones de otro,
 * para que ninguno de ellos necesite conocer a los demas directamente.
 * <p>
 * Gracias a {@code fx:include fx:id="xxx"} en el FXML, JavaFX inyecta
 * automaticamente cada sub-controller en el campo {@code xxxController} de
 * esta clase.
 */
public class MainController {

    // Sub-controllers inyectados automaticamente por fx:include (convencion "<fx:id>Controller")
    @FXML private ToolbarController toolbarController;
    @FXML private MetricsPanelController metricsPanelController;
    @FXML private LogsTableController logsTableController;
    @FXML private DetailPanelController detailPanelController;
    @FXML private ConsolePanelController consolePanelController;

    // ---------------------------------------------------------------- Services (inyeccion manual, sin framework DI)
    private final LogIngestionService ingestionService = new LogIngestionService();
    private final DetectionEngine detectionEngine = new DetectionEngine();
    private final MockLogGenerator mockLogGenerator = new MockLogGenerator();
    private final SoarService soarService = new SoarService();

    private final ObservableList<LogEntry> masterData = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        logsTableController.setMasterData(masterData);

        wireToolbarActions();
        wireToolbarFilters();
        wireTableSelection();
        wireDetailPlaybookRequests();

        metricsPanelController.update(masterData);
        consolePanelController.appendLine("Consola SOAR lista. Esperando ingesta de logs o generacion de datos de prueba...");
    }

    // ================================================================== wiring entre sub-controllers

    private void wireToolbarActions() {
        toolbarController.setOnLoadJsonRequested(this::handleLoadJson);
        toolbarController.setOnLoadCsvRequested(this::handleLoadCsv);
        toolbarController.setOnGenerateMockRequested(this::handleGenerateMock);
    }

    private void wireToolbarFilters() {
        toolbarController.searchTextProperty().addListener((obs, oldVal, newVal) -> applyFilters());
        toolbarController.severityFilterProperty().addListener((obs, oldVal, newVal) -> applyFilters());
    }

    private void wireTableSelection() {
        logsTableController.selectedItemProperty()
                .addListener((obs, oldSelection, newSelection) -> detailPanelController.showDetail(newSelection));
    }

    private void wireDetailPlaybookRequests() {
        detailPanelController.setOnPlaybookRequested(this::handlePlaybookRequested);
    }

    private void applyFilters() {
        logsTableController.applyFilters(toolbarController.getSearchText(), toolbarController.getSeverityFilter());
    }

    // ================================================================== data loading actions

    private void handleLoadJson() {
        FileChooser chooser = buildChooser("Seleccionar archivo de logs JSON",
                new FileChooser.ExtensionFilter("Archivos JSON", "*.json"));
        File file = chooser.showOpenDialog(getWindow());
        if (file == null) {
            return;
        }
        try {
            List<LogEntry> newLogs = ingestionService.loadFromJson(file);
            ingestAndAnalyze(newLogs, "Cargados " + newLogs.size() + " eventos desde " + file.getName());
        } catch (IOException e) {
            showError("No se pudo leer el archivo JSON", e.getMessage());
        }
    }

    private void handleLoadCsv() {
        FileChooser chooser = buildChooser("Seleccionar archivo de logs CSV",
                new FileChooser.ExtensionFilter("Archivos CSV", "*.csv"));
        File file = chooser.showOpenDialog(getWindow());
        if (file == null) {
            return;
        }
        try {
            List<LogEntry> newLogs = ingestionService.loadFromCsv(file);
            ingestAndAnalyze(newLogs, "Cargados " + newLogs.size() + " eventos desde " + file.getName());
        } catch (IOException e) {
            showError("No se pudo leer el archivo CSV", e.getMessage());
        }
    }

    private void handleGenerateMock() {
        List<LogEntry> newLogs = mockLogGenerator.generateSampleBatch();
        ingestAndAnalyze(newLogs, "Generados " + newLogs.size() + " eventos sinteticos de demostracion");
    }

    private void ingestAndAnalyze(List<LogEntry> newLogs, String statusMessage) {
        detectionEngine.analyze(newLogs, masterData);
        masterData.addAll(newLogs);

        long alertCount = newLogs.stream().filter(l -> l.getSeverity().isAlert()).count();
        metricsPanelController.update(masterData);
        consolePanelController.setStatus(statusMessage + " | " + alertCount + " nuevas alertas detectadas.");
        consolePanelController.appendLine("[INGESTA] " + statusMessage + " (" + alertCount + " alertas)");
    }

    // ================================================================== SOAR playbook

    private void handlePlaybookRequested(LogEntry selected) {
        if (selected.getSeverity() != Severity.HIGH) {
            showInfo("Accion no disponible",
                    "El playbook de contencion automatica solo aplica a alertas de severidad ALTA.");
            return;
        }
        if ("CONTAINED".equals(selected.getStatus())) {
            showInfo("Ya contenida", "Esta alerta ya fue marcada como contenida previamente.");
            return;
        }

        List<String> steps = soarService.executeContainmentPlaybook(selected);
        steps.forEach(consolePanelController::appendLine);

        logsTableController.refresh();
        detailPanelController.showDetail(selected);
        consolePanelController.setStatus("Playbook de contencion ejecutado sobre alerta #" + selected.getId()
                + " (IP " + selected.getSourceIp() + ")");
    }

    // ================================================================== helpers

    private FileChooser buildChooser(String title, FileChooser.ExtensionFilter filter) {
        FileChooser chooser = new FileChooser();
        chooser.setTitle(title);
        chooser.getExtensionFilters().add(filter);
        return chooser;
    }

    private Window getWindow() {
        return logsTableController.getWindow();
    }

    private void showError(String header, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }

    private void showInfo(String header, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Informacion");
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
