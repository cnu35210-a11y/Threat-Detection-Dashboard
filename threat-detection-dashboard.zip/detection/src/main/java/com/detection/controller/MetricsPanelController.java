package com.detection.controller;

import com.detection.model.LogEntry;
import com.detection.model.Severity;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Controller del panel lateral de metricas (KPIs de severidad + Top IPs
 * origen). Es un componente puramente de presentacion: recibe el snapshot de
 * datos a mostrar via {@link #update(List)} y no conoce servicios, reglas ni
 * la tabla principal.
 */
public class MetricsPanelController {

    @FXML private Label totalEventsLabel;
    @FXML private Label highCountLabel;
    @FXML private Label mediumCountLabel;
    @FXML private Label lowCountLabel;
    @FXML private Label infoCountLabel;
    @FXML private VBox topIpsBox;

    /** Recalcula y repinta todas las metricas a partir del set completo de eventos actuales. */
    public void update(List<LogEntry> allLogs) {
        totalEventsLabel.setText(String.valueOf(allLogs.size()));

        Map<Severity, Long> counts = allLogs.stream()
                .collect(Collectors.groupingBy(LogEntry::getSeverity, Collectors.counting()));

        highCountLabel.setText(String.valueOf(counts.getOrDefault(Severity.HIGH, 0L)));
        mediumCountLabel.setText(String.valueOf(counts.getOrDefault(Severity.MEDIUM, 0L)));
        lowCountLabel.setText(String.valueOf(counts.getOrDefault(Severity.LOW, 0L)));
        infoCountLabel.setText(String.valueOf(counts.getOrDefault(Severity.INFO, 0L)));

        renderTopSourceIps(allLogs);
    }

    private void renderTopSourceIps(List<LogEntry> allLogs) {
        topIpsBox.getChildren().clear();

        Map<String, Long> ipCounts = allLogs.stream()
                .filter(log -> log.getSourceIp() != null && !"-".equals(log.getSourceIp()))
                .collect(Collectors.groupingBy(LogEntry::getSourceIp, Collectors.counting()));

        if (ipCounts.isEmpty()) {
            Label placeholder = new Label("Sin datos aun");
            placeholder.getStyleClass().add("muted-text");
            topIpsBox.getChildren().add(placeholder);
            return;
        }

        ipCounts.entrySet().stream()
                .sorted(Map.Entry.<String, Long>comparingByValue().reversed())
                .limit(5)
                .forEach(entryCount -> topIpsBox.getChildren().add(buildTopIpRow(entryCount.getKey(), entryCount.getValue())));
    }

    private HBox buildTopIpRow(String ip, long count) {
        HBox row = new HBox();
        row.getStyleClass().add("top-ip-row");

        Label ipLabel = new Label(ip);
        ipLabel.getStyleClass().add("top-ip-label");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Label countLabel = new Label(String.valueOf(count));
        countLabel.getStyleClass().add("top-ip-count");

        row.getChildren().addAll(ipLabel, spacer, countLabel);
        return row;
    }
}
