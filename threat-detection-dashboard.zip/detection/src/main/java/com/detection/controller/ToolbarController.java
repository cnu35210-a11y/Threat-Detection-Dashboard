package com.detection.controller;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

/**
 * Controller de la barra superior (titulo + toolbar de acciones y filtros).
 * <p>
 * Responsabilidad unica: capturar la intencion del usuario (cargar JSON/CSV,
 * generar datos de prueba, escribir una busqueda, elegir una severidad) y
 * exponerla mediante callbacks/propiedades, sin conocer nada sobre la tabla,
 * las metricas ni el motor de deteccion. Es {@link MainController} quien
 * conecta estas señales con el resto de la aplicacion (patron Mediator).
 */
public class ToolbarController {

    @FXML private TextField searchField;
    @FXML private ComboBox<String> severityFilterCombo;
    @FXML private Button loadJsonButton;
    @FXML private Button loadCsvButton;
    @FXML private Button generateMockButton;

    private Runnable onLoadJsonRequested;
    private Runnable onLoadCsvRequested;
    private Runnable onGenerateMockRequested;

    @FXML
    public void initialize() {
        severityFilterCombo.setItems(FXCollections.observableArrayList(
                "TODAS", "HIGH", "MEDIUM", "LOW", "INFO"));
        severityFilterCombo.getSelectionModel().selectFirst();
    }

    // ---------------------------------------------------------------- FXML actions
    @FXML
    private void handleLoadJson() {
        if (onLoadJsonRequested != null) {
            onLoadJsonRequested.run();
        }
    }

    @FXML
    private void handleLoadCsv() {
        if (onLoadCsvRequested != null) {
            onLoadCsvRequested.run();
        }
    }

    @FXML
    private void handleGenerateMock() {
        if (onGenerateMockRequested != null) {
            onGenerateMockRequested.run();
        }
    }

    // ---------------------------------------------------------------- callbacks (wired by MainController)
    public void setOnLoadJsonRequested(Runnable handler) { this.onLoadJsonRequested = handler; }
    public void setOnLoadCsvRequested(Runnable handler) { this.onLoadCsvRequested = handler; }
    public void setOnGenerateMockRequested(Runnable handler) { this.onGenerateMockRequested = handler; }

    // ---------------------------------------------------------------- observable state exposed to MainController
    public StringProperty searchTextProperty() { return searchField.textProperty(); }
    public ObjectProperty<String> severityFilterProperty() { return severityFilterCombo.valueProperty(); }

    public String getSearchText() { return searchField.getText(); }
    public String getSeverityFilter() { return severityFilterCombo.getValue(); }
}
