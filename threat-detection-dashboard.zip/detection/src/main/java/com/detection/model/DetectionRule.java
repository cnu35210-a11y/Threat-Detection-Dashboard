package com.detection.model;

import java.util.List;

/**
 * Contrato para una regla de deteccion, inspirado en la estructura de una
 * regla Sigma/YARA: metadatos descriptivos + mapeo MITRE ATT&amp;CK + una
 * condicion de evaluacion.
 * <p>
 * Cada implementacion concreta vive en {@code com.detection.service.rule} y
 * es registrada en el {@link com.detection.service.DetectionEngine}, que las
 * ejecuta en orden contra cada log entrante (patron Strategy).
 */
public interface DetectionRule {

    /** Identificador corto y estable de la regla, ej. "BF-SSH-001". */
    String getId();

    /** Nombre legible, ej. "SSH Brute Force". */
    String getName();

    /** Severidad que se asigna al log cuando la regla se dispara. */
    Severity getSeverity();

    /** Tecnica MITRE ATT&amp;CK asociada, ej. "T1110". */
    String getMitreId();

    /** Nombre de la tactica/tecnica MITRE, ej. "Brute Force". */
    String getMitreTechnique();

    /** Descripcion completa mostrada en el panel de detalle al usuario. */
    String getDescription();

    /**
     * Evalua si el log {@code current} cumple la condicion de esta regla.
     * <p>
     * Para reglas de correlacion (ej. fuerza bruta, escaneo de puertos) el
     * parametro {@code history} entrega los eventos previamente procesados
     * (incluyendo {@code current}), ordenados cronologicamente, para poder
     * calcular ventanas de tiempo y umbrales.
     *
     * @param current evento actualmente en evaluacion
     * @param history eventos ya procesados en la sesion, orden cronologico ascendente
     * @return {@code true} si la regla se dispara para este evento
     */
    boolean evaluate(LogEntry current, List<LogEntry> history);
}
