package com.detection.model;

import javafx.beans.property.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Representa un evento de log normalizado dentro del Mini-SIEM.
 * <p>
 * Un {@code LogEntry} nace como un evento "crudo" (ingestado desde JSON/CSV o
 * generado por {@link com.detection.service.MockLogGenerator}) y es luego
 * enriquecido por el {@link com.detection.service.DetectionEngine}, que le
 * asigna severidad, regla disparada e informacion MITRE ATT&amp;CK cuando
 * corresponde.
 * <p>
 * Se implementa con propiedades JavaFX (Simple*Property) para poder
 * enlazarse directamente a un {@code TableView} y refrescar la UI de forma
 * reactiva.
 */
public class LogEntry {

    /** Generador de identificadores unicos, compartido por toda la aplicacion. */
    private static final AtomicInteger ID_SEQUENCE = new AtomicInteger(1);
    public static final DateTimeFormatter DISPLAY_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public static int nextId() {
        return ID_SEQUENCE.getAndIncrement();
    }

    // ---- Datos crudos del evento -------------------------------------------------
    private final IntegerProperty id = new SimpleIntegerProperty(this, "id");
    private final ObjectProperty<LocalDateTime> timestamp = new SimpleObjectProperty<>(this, "timestamp");
    private final StringProperty sourceIp = new SimpleStringProperty(this, "sourceIp", "-");
    private final StringProperty destinationIp = new SimpleStringProperty(this, "destinationIp", "-");
    private final StringProperty eventType = new SimpleStringProperty(this, "eventType", "unknown");
    private final StringProperty user = new SimpleStringProperty(this, "user", "-");
    private final ObjectProperty<Integer> port = new SimpleObjectProperty<>(this, "port", null);
    private final StringProperty process = new SimpleStringProperty(this, "process", "-");
    private final StringProperty commandLine = new SimpleStringProperty(this, "commandLine", "-");
    private final StringProperty message = new SimpleStringProperty(this, "message", "");
    private final StringProperty rawLog = new SimpleStringProperty(this, "rawLog", "{}");
    private final StringProperty source = new SimpleStringProperty(this, "source", "generic");

    // ---- Resultado del motor de deteccion -----------------------------------------
    private final ObjectProperty<Severity> severity = new SimpleObjectProperty<>(this, "severity", Severity.INFO);
    private final StringProperty ruleMatched = new SimpleStringProperty(this, "ruleMatched", "-");
    private final StringProperty mitreId = new SimpleStringProperty(this, "mitreId", "-");
    private final StringProperty mitreTechnique = new SimpleStringProperty(this, "mitreTechnique", "-");
    private final StringProperty mitreDescription = new SimpleStringProperty(this, "mitreDescription",
            "Sin coincidencias con reglas de deteccion. Evento clasificado como normal.");
    private final StringProperty status = new SimpleStringProperty(this, "status", "NEW");

    public LogEntry() {
        this.id.set(nextId());
    }

    // ---------------------------------------------------------------- id
    public int getId() { return id.get(); }
    public void setId(int value) { id.set(value); }
    public IntegerProperty idProperty() { return id; }

    // ---------------------------------------------------------------- timestamp
    public LocalDateTime getTimestamp() { return timestamp.get(); }
    public void setTimestamp(LocalDateTime value) { timestamp.set(value); }
    public ObjectProperty<LocalDateTime> timestampProperty() { return timestamp; }
    public String getFormattedTimestamp() {
        return timestamp.get() == null ? "-" : timestamp.get().format(DISPLAY_FORMAT);
    }

    // ---------------------------------------------------------------- sourceIp
    public String getSourceIp() { return sourceIp.get(); }
    public void setSourceIp(String value) { sourceIp.set(value); }
    public StringProperty sourceIpProperty() { return sourceIp; }

    // ---------------------------------------------------------------- destinationIp
    public String getDestinationIp() { return destinationIp.get(); }
    public void setDestinationIp(String value) { destinationIp.set(value); }
    public StringProperty destinationIpProperty() { return destinationIp; }

    // ---------------------------------------------------------------- eventType
    public String getEventType() { return eventType.get(); }
    public void setEventType(String value) { eventType.set(value); }
    public StringProperty eventTypeProperty() { return eventType; }

    // ---------------------------------------------------------------- user
    public String getUser() { return user.get(); }
    public void setUser(String value) { user.set(value); }
    public StringProperty userProperty() { return user; }

    // ---------------------------------------------------------------- port
    public Integer getPort() { return port.get(); }
    public void setPort(Integer value) { port.set(value); }
    public ObjectProperty<Integer> portProperty() { return port; }

    // ---------------------------------------------------------------- process
    public String getProcess() { return process.get(); }
    public void setProcess(String value) { process.set(value); }
    public StringProperty processProperty() { return process; }

    // ---------------------------------------------------------------- commandLine
    public String getCommandLine() { return commandLine.get(); }
    public void setCommandLine(String value) { commandLine.set(value); }
    public StringProperty commandLineProperty() { return commandLine; }

    // ---------------------------------------------------------------- message
    public String getMessage() { return message.get(); }
    public void setMessage(String value) { message.set(value); }
    public StringProperty messageProperty() { return message; }

    // ---------------------------------------------------------------- rawLog
    public String getRawLog() { return rawLog.get(); }
    public void setRawLog(String value) { rawLog.set(value); }
    public StringProperty rawLogProperty() { return rawLog; }

    // ---------------------------------------------------------------- source (origen de ingesta)
    public String getSource() { return source.get(); }
    public void setSource(String value) { source.set(value); }
    public StringProperty sourceProperty() { return source; }

    // ---------------------------------------------------------------- severity
    public Severity getSeverity() { return severity.get(); }
    public void setSeverity(Severity value) { severity.set(value); }
    public ObjectProperty<Severity> severityProperty() { return severity; }

    // ---------------------------------------------------------------- ruleMatched
    public String getRuleMatched() { return ruleMatched.get(); }
    public void setRuleMatched(String value) { ruleMatched.set(value); }
    public StringProperty ruleMatchedProperty() { return ruleMatched; }

    // ---------------------------------------------------------------- mitreId
    public String getMitreId() { return mitreId.get(); }
    public void setMitreId(String value) { mitreId.set(value); }
    public StringProperty mitreIdProperty() { return mitreId; }

    // ---------------------------------------------------------------- mitreTechnique
    public String getMitreTechnique() { return mitreTechnique.get(); }
    public void setMitreTechnique(String value) { mitreTechnique.set(value); }
    public StringProperty mitreTechniqueProperty() { return mitreTechnique; }

    // ---------------------------------------------------------------- mitreDescription
    public String getMitreDescription() { return mitreDescription.get(); }
    public void setMitreDescription(String value) { mitreDescription.set(value); }
    public StringProperty mitreDescriptionProperty() { return mitreDescription; }

    // ---------------------------------------------------------------- status
    public String getStatus() { return status.get(); }
    public void setStatus(String value) { status.set(value); }
    public StringProperty statusProperty() { return status; }

    @Override
    public String toString() {
        return "LogEntry{" +
                "id=" + getId() +
                ", timestamp=" + getFormattedTimestamp() +
                ", sourceIp='" + getSourceIp() + '\'' +
                ", eventType='" + getEventType() + '\'' +
                ", severity=" + getSeverity() +
                '}';
    }
}
