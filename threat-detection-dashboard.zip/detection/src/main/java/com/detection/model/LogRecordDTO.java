package com.detection.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.time.LocalDateTime;

/**
 * Objeto de transferencia (DTO) que refleja fielmente el esquema del log
 * "crudo" tal como llega desde un archivo JSON o CSV (simulando Sysmon,
 * Windows Event Log o Linux auth.log ya normalizados a un formato comun).
 * <p>
 * Se mantiene deliberadamente separado de {@link LogEntry} (que es un modelo
 * de UI con propiedades JavaFX) para no acoplar la deserializacion de Jackson
 * con la capa de presentacion.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LogRecordDTO {

    private LocalDateTime timestamp;
    private String sourceIp;
    private String destinationIp;
    private String eventType;
    private String user;
    private Integer port;
    private String process;
    private String commandLine;
    private String message;

    public LogRecordDTO() {
        // Constructor vacio requerido por Jackson
    }

    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }

    public String getSourceIp() { return sourceIp; }
    public void setSourceIp(String sourceIp) { this.sourceIp = sourceIp; }

    public String getDestinationIp() { return destinationIp; }
    public void setDestinationIp(String destinationIp) { this.destinationIp = destinationIp; }

    public String getEventType() { return eventType; }
    public void setEventType(String eventType) { this.eventType = eventType; }

    public String getUser() { return user; }
    public void setUser(String user) { this.user = user; }

    public Integer getPort() { return port; }
    public void setPort(Integer port) { this.port = port; }

    public String getProcess() { return process; }
    public void setProcess(String process) { this.process = process; }

    public String getCommandLine() { return commandLine; }
    public void setCommandLine(String commandLine) { this.commandLine = commandLine; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
}
