package com.detection.model;

/**
 * Nivel de severidad de un evento o alerta.
 * El orden declarado (INFO &lt; LOW &lt; MEDIUM &lt; HIGH) se usa para decidir,
 * cuando varias reglas de deteccion coinciden sobre un mismo log, cual
 * severidad debe prevalecer (siempre la mas alta).
 */
public enum Severity {

    INFO("Informativo", "#4FC3F7"),
    LOW("Baja", "#8BC34A"),
    MEDIUM("Media", "#FFB300"),
    HIGH("Alta", "#FF5252");

    private final String label;
    private final String colorHex;

    Severity(String label, String colorHex) {
        this.label = label;
        this.colorHex = colorHex;
    }

    public String getLabel() {
        return label;
    }

    public String getColorHex() {
        return colorHex;
    }

    /** Nombre de estilo CSS asociado, ej. "severity-high". Usado en cellFactories/rowFactories. */
    public String getStyleClass() {
        return "severity-" + name().toLowerCase();
    }

    public boolean isAlert() {
        return this == MEDIUM || this == HIGH;
    }
}
