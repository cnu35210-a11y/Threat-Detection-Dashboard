package com.detection.service;

import com.detection.model.DetectionRule;
import com.detection.model.LogEntry;
import com.detection.model.Severity;
import com.detection.service.rule.BruteForceSshRule;
import com.detection.service.rule.EncodedPowerShellRule;
import com.detection.service.rule.MimikatzExecutionRule;
import com.detection.service.rule.PortScanRule;
import com.detection.service.rule.PrivilegeEscalationRule;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Motor de correlacion y deteccion del Mini-SIEM.
 * <p>
 * Mantiene el catalogo de {@link DetectionRule} activas (patron Strategy) y
 * las evalua contra cada {@link LogEntry} entrante, respetando el historial
 * de eventos ya procesados para poder resolver reglas de correlacion con
 * ventana temporal (fuerza bruta, escaneo de puertos, etc).
 * <p>
 * Cuando varias reglas coinciden sobre el mismo evento, prevalece la de
 * mayor severidad.
 */
public class DetectionEngine {

    private final List<DetectionRule> rules;

    public DetectionEngine() {
        this.rules = List.of(
                new BruteForceSshRule(),
                new MimikatzExecutionRule(),
                new PrivilegeEscalationRule(),
                new PortScanRule(),
                new EncodedPowerShellRule()
        );
    }

    /** Permite inyectar un catalogo de reglas personalizado (util para pruebas unitarias). */
    public DetectionEngine(List<DetectionRule> customRules) {
        this.rules = List.copyOf(customRules);
    }

    public List<DetectionRule> getRules() {
        return rules;
    }

    /**
     * Analiza un lote de logs nuevos, usando {@code existingHistory} como
     * contexto adicional para las reglas de correlacion (por ejemplo, para
     * poder detectar que un nuevo lote continua un ataque ya en curso).
     * <p>
     * Los logs se procesan en orden cronologico y el resultado (severidad,
     * regla, info MITRE) se escribe directamente sobre cada {@link LogEntry}.
     *
     * @param newLogs         logs recien ingestados/generados, sin analizar
     * @param existingHistory logs ya presentes en el dashboard (puede estar vacia)
     * @return la misma lista {@code newLogs}, ya enriquecida, ordenada cronologicamente
     */
    public List<LogEntry> analyze(List<LogEntry> newLogs, List<LogEntry> existingHistory) {
        List<LogEntry> sortedNew = new ArrayList<>(newLogs);
        sortedNew.sort(Comparator.comparing(LogEntry::getTimestamp,
                Comparator.nullsLast(Comparator.naturalOrder())));

        // El "historial de trabajo" crece incrementalmente: cada log evaluado
        // pasa a formar parte del contexto para el siguiente, permitiendo que
        // las reglas de correlacion vean el ataque completo a medida que avanza.
        List<LogEntry> workingHistory = new ArrayList<>(existingHistory);

        for (LogEntry log : sortedNew) {
            resetToBaseline(log);
            workingHistory.add(log);
            applyRules(log, workingHistory);
        }
        return sortedNew;
    }

    /** Evalua un unico log adicional contra el historial completo ya existente. */
    public void analyzeSingle(LogEntry log, List<LogEntry> fullHistoryIncludingCurrent) {
        resetToBaseline(log);
        applyRules(log, fullHistoryIncludingCurrent);
    }

    // ------------------------------------------------------------------ helpers

    private void resetToBaseline(LogEntry log) {
        log.setSeverity(Severity.INFO);
        log.setRuleMatched("-");
        log.setMitreId("-");
        log.setMitreTechnique("-");
        log.setMitreDescription("Sin coincidencias con reglas de deteccion. Evento clasificado como normal.");
    }

    private void applyRules(LogEntry log, List<LogEntry> history) {
        DetectionRule winningRule = null;

        for (DetectionRule rule : rules) {
            boolean triggered;
            try {
                triggered = rule.evaluate(log, history);
            } catch (Exception e) {
                // Una regla mal formada nunca debe tumbar el pipeline de analisis completo.
                triggered = false;
            }
            if (triggered && (winningRule == null || rule.getSeverity().ordinal() > winningRule.getSeverity().ordinal())) {
                winningRule = rule;
            }
        }

        if (winningRule != null) {
            log.setSeverity(winningRule.getSeverity());
            log.setRuleMatched(winningRule.getName() + " (" + winningRule.getId() + ")");
            log.setMitreId(winningRule.getMitreId());
            log.setMitreTechnique(winningRule.getMitreTechnique());
            log.setMitreDescription(winningRule.getDescription());
        } else if ("authentication_failure".equalsIgnoreCase(log.getEventType())) {
            // Un fallo aislado (por debajo del umbral de fuerza bruta) igual merece atencion baja.
            log.setSeverity(Severity.LOW);
            log.setMitreDescription("Fallo de autenticacion aislado. No alcanza el umbral de correlacion "
                    + "de fuerza bruta, pero se recomienda mantener vigilancia sobre esta IP/usuario.");
        }
    }
}
