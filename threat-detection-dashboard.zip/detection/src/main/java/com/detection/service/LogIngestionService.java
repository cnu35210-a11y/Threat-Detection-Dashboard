package com.detection.service;

import com.detection.model.LogEntry;
import com.detection.model.LogRecordDTO;
import com.detection.util.JsonUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.type.TypeReference;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

/**
 * Motor de ingesta: sabe leer archivos de log en disco (JSON o CSV,
 * simulando la salida ya normalizada de Sysmon / Windows Event Log / Linux
 * auth.log) y convertirlos en objetos {@link LogEntry} listos para ser
 * evaluados por el {@link DetectionEngine}.
 * <p>
 * En esta etapa NO se calcula severidad ni se dispara ninguna regla: la
 * ingesta solo normaliza datos. La deteccion es responsabilidad exclusiva de
 * {@link DetectionEngine}, respetando el principio de responsabilidad unica.
 */
public class LogIngestionService {

    private static final DateTimeFormatter[] CSV_DATE_FORMATS = {
            DateTimeFormatter.ISO_LOCAL_DATE_TIME,
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"),
            DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss")
    };

    /**
     * Carga un archivo JSON que contiene un arreglo de registros de log con
     * el esquema de {@link LogRecordDTO}.
     */
    public List<LogEntry> loadFromJson(File file) throws IOException {
        ObjectMapper mapper = JsonUtil.mapper();
        List<LogRecordDTO> records = mapper.readValue(file, new TypeReference<List<LogRecordDTO>>() {});

        List<LogEntry> entries = new ArrayList<>();
        for (LogRecordDTO dto : records) {
            entries.add(toLogEntry(dto, "json:" + file.getName()));
        }
        return entries;
    }

    /**
     * Carga un archivo CSV con cabecera:
     * timestamp,sourceIp,destinationIp,eventType,user,port,process,commandLine,message
     * <p>
     * Se implementa un parser manual (sin dependencias externas) que respeta
     * campos entre comillas dobles que puedan contener comas.
     */
    public List<LogEntry> loadFromCsv(File file) throws IOException {
        List<String> lines = Files.readAllLines(file.toPath());
        if (lines.isEmpty()) {
            return List.of();
        }

        String[] headers = splitCsvLine(lines.get(0));
        List<LogEntry> entries = new ArrayList<>();

        for (int i = 1; i < lines.size(); i++) {
            String line = lines.get(i).trim();
            if (line.isEmpty()) {
                continue;
            }
            String[] values = splitCsvLine(line);
            LogRecordDTO dto = new LogRecordDTO();

            for (int col = 0; col < headers.length && col < values.length; col++) {
                String header = headers[col].trim();
                String value = values[col].trim();
                if (value.isEmpty() || value.equalsIgnoreCase("null")) {
                    continue;
                }
                assignField(dto, header, value);
            }
            entries.add(toLogEntry(dto, "csv:" + file.getName()));
        }
        return entries;
    }

    // ------------------------------------------------------------------ helpers

    private void assignField(LogRecordDTO dto, String header, String value) {
        switch (header.toLowerCase()) {
            case "timestamp" -> dto.setTimestamp(parseFlexibleDate(value));
            case "sourceip", "source_ip", "src_ip" -> dto.setSourceIp(value);
            case "destinationip", "destination_ip", "dst_ip" -> dto.setDestinationIp(value);
            case "eventtype", "event_type" -> dto.setEventType(value);
            case "user", "username" -> dto.setUser(value);
            case "port" -> dto.setPort(parseIntSafe(value));
            case "process" -> dto.setProcess(value);
            case "commandline", "command_line" -> dto.setCommandLine(value);
            case "message" -> dto.setMessage(value);
            default -> { /* columna desconocida: se ignora silenciosamente */ }
        }
    }

    private LocalDateTime parseFlexibleDate(String raw) {
        for (DateTimeFormatter fmt : CSV_DATE_FORMATS) {
            try {
                return LocalDateTime.parse(raw, fmt);
            } catch (DateTimeParseException ignored) {
                // se intenta con el siguiente formato
            }
        }
        return LocalDateTime.now();
    }

    private Integer parseIntSafe(String value) {
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private String[] splitCsvLine(String line) {
        // Divide por comas que no esten dentro de comillas dobles
        String[] rawTokens = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1);
        String[] cleaned = new String[rawTokens.length];
        for (int i = 0; i < rawTokens.length; i++) {
            cleaned[i] = rawTokens[i].trim().replaceAll("^\"|\"$", "");
        }
        return cleaned;
    }

    private LogEntry toLogEntry(LogRecordDTO dto, String source) {
        LogEntry entry = new LogEntry();
        entry.setTimestamp(dto.getTimestamp() != null ? dto.getTimestamp() : LocalDateTime.now());
        entry.setSourceIp(nullSafe(dto.getSourceIp()));
        entry.setDestinationIp(nullSafe(dto.getDestinationIp()));
        entry.setEventType(nullSafe(dto.getEventType()));
        entry.setUser(nullSafe(dto.getUser()));
        entry.setPort(dto.getPort());
        entry.setProcess(nullSafe(dto.getProcess()));
        entry.setCommandLine(nullSafe(dto.getCommandLine()));
        entry.setMessage(dto.getMessage() != null ? dto.getMessage() : "");
        entry.setSource(source);
        entry.setRawLog(JsonUtil.toPrettyJson(dto));
        return entry;
    }

    private String nullSafe(String value) {
        return value == null || value.isBlank() ? "-" : value;
    }
}
