package com.detection.service;

import com.detection.model.LogEntry;
import com.detection.model.LogRecordDTO;
import com.detection.util.JsonUtil;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Generador de logs sinteticos ("Mock Log Generator") usado para poblar el
 * dashboard con datos realistas sin depender de un archivo externo.
 * <p>
 * Combina trafico benigno (autenticaciones exitosas, procesos normales,
 * conexiones de red rutinarias) con escenarios de ataque reconocibles por el
 * {@link DetectionEngine}: fuerza bruta SSH, ejecucion de Mimikatz,
 * escalamiento de privilegios, escaneo de puertos y PowerShell codificado.
 */
public class MockLogGenerator {

    private final Random random = new Random();

    private static final String[] BENIGN_SOURCE_IPS = {
            "10.0.0.11", "10.0.0.23", "10.0.0.34", "192.168.1.45", "192.168.1.52"
    };
    private static final String[] BENIGN_USERS = {"jdoe", "asmith", "mrivas", "kgarcia", "svc_backup"};
    private static final String[] BENIGN_PROCESSES = {
            "explorer.exe", "chrome.exe", "outlook.exe", "bash", "sshd", "code.exe", "teams.exe"
    };
    private static final String[] INTERNAL_HOSTS = {"10.0.0.5", "10.0.0.6", "10.0.0.10"};

    /**
     * Genera un lote completo de logs de demostracion, distribuidos en la
     * ultima hora, listos para ser pasados al {@link DetectionEngine}.
     */
    public List<LogEntry> generateSampleBatch() {
        LocalDateTime base = LocalDateTime.now().minusMinutes(58);
        List<LogEntry> logs = new ArrayList<>();

        logs.addAll(generateBenignTraffic(base, 22));
        logs.addAll(generateSshBruteForce(base.plusMinutes(12)));
        logs.addAll(generateMimikatzExecution(base.plusMinutes(24)));
        logs.addAll(generatePrivilegeEscalation(base.plusMinutes(26)));
        logs.addAll(generatePortScan(base.plusMinutes(38)));
        logs.addAll(generateEncodedPowerShell(base.plusMinutes(45)));
        logs.addAll(generateBenignTraffic(base.plusMinutes(50), 15));

        logs.sort((a, b) -> a.getTimestamp().compareTo(b.getTimestamp()));
        return logs;
    }

    // ------------------------------------------------------------------ escenarios

    private List<LogEntry> generateBenignTraffic(LocalDateTime start, int count) {
        List<LogEntry> logs = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            LocalDateTime ts = start.plusSeconds((long) (random.nextInt(400)));
            String kind = randomOf("auth_success", "process", "network");
            LogEntry entry;
            switch (kind) {
                case "auth_success" -> entry = build(ts, randomOf(BENIGN_SOURCE_IPS), randomOf(INTERNAL_HOSTS),
                        "authentication_success", randomOf(BENIGN_USERS), 22, "sshd", "-",
                        "Accepted password for user from internal network");
                case "process" -> entry = build(ts, randomOf(BENIGN_SOURCE_IPS), randomOf(INTERNAL_HOSTS),
                        "process_creation", randomOf(BENIGN_USERS), null, randomOf(BENIGN_PROCESSES),
                        randomOf(BENIGN_PROCESSES) + " --normal-startup",
                        "Proceso de usuario iniciado de forma rutinaria");
                default -> entry = build(ts, randomOf(BENIGN_SOURCE_IPS), randomOf(INTERNAL_HOSTS),
                        "network_connection", randomOf(BENIGN_USERS), randomOf(80, 443, 3306),
                        "chrome.exe", "-", "Conexion saliente normal a servicio interno");
            }
            logs.add(entry);
        }
        return logs;
    }

    private List<LogEntry> generateSshBruteForce(LocalDateTime start) {
        List<LogEntry> logs = new ArrayList<>();
        String attackerIp = "203.0.113.45";
        String target = "10.0.0.5";
        for (int i = 0; i < 7; i++) {
            LocalDateTime ts = start.plusSeconds(i);
            logs.add(build(ts, attackerIp, target, "authentication_failure", "root", 22, "sshd", "-",
                    "Failed password for root from " + attackerIp + " port " + (50000 + i) + " ssh2"));
        }
        // Al octavo intento, el atacante logra acceso (credenciales debiles comprometidas).
        logs.add(build(start.plusSeconds(9), attackerIp, target, "authentication_success", "root", 22,
                "sshd", "-", "Accepted password for root from " + attackerIp + " port 50099 ssh2 - POSIBLE COMPROMISO"));
        return logs;
    }

    private List<LogEntry> generateMimikatzExecution(LocalDateTime start) {
        List<LogEntry> logs = new ArrayList<>();
        logs.add(build(start, "10.0.0.5", "10.0.0.5", "process_creation", "jdoe", null,
                "mimikatz.exe", "mimikatz.exe \"privilege::debug\" \"sekurlsa::logonpasswords\" \"exit\"",
                "Ejecucion de utilidad de volcado de credenciales detectada en WIN-CORP01"));
        return logs;
    }

    private List<LogEntry> generatePrivilegeEscalation(LocalDateTime start) {
        List<LogEntry> logs = new ArrayList<>();
        logs.add(build(start, "10.0.0.5", "10.0.0.5", "privilege_escalation", "jdoe", null,
                "net.exe", "net localgroup administrators jdoe /add",
                "User jdoe added to group Administrators en WIN-CORP01 (Event ID 4732)"));
        return logs;
    }

    private List<LogEntry> generatePortScan(LocalDateTime start) {
        List<LogEntry> logs = new ArrayList<>();
        String attackerIp = "198.51.100.23";
        String target = "10.0.0.5";
        int[] ports = {21, 22, 23, 80, 443, 3389, 8080, 8443};
        for (int i = 0; i < ports.length; i++) {
            LocalDateTime ts = start.plusSeconds(i * 2L);
            logs.add(build(ts, attackerIp, target, "network_connection", "-", ports[i], "nmap", "-",
                    "Intento de conexion TCP a puerto " + ports[i] + " (SYN scan)"));
        }
        return logs;
    }

    private List<LogEntry> generateEncodedPowerShell(LocalDateTime start) {
        List<LogEntry> logs = new ArrayList<>();
        String encoded = "JABzAD0ATgBlAHcALQBPAGIAagBlAGMAdAAgAE4AZQB0AC4AVwBlAGIAQwBsAGkAZQBuAHQA";
        logs.add(build(start, "10.0.0.6", "198.51.100.99", "process_creation", "svc_backup", null,
                "powershell.exe", "powershell.exe -NoProfile -WindowStyle Hidden -EncodedCommand " + encoded,
                "Ejecucion de PowerShell con comando codificado en Base64, posible descarga de payload"));
        return logs;
    }

    // ------------------------------------------------------------------ helpers

    private LogEntry build(LocalDateTime ts, String sourceIp, String destIp, String eventType, String user,
                            Integer port, String process, String commandLine, String message) {
        LogRecordDTO dto = new LogRecordDTO();
        dto.setTimestamp(ts);
        dto.setSourceIp(sourceIp);
        dto.setDestinationIp(destIp);
        dto.setEventType(eventType);
        dto.setUser(user);
        dto.setPort(port);
        dto.setProcess(process);
        dto.setCommandLine(commandLine);
        dto.setMessage(message);

        LogEntry entry = new LogEntry();
        entry.setTimestamp(ts);
        entry.setSourceIp(sourceIp);
        entry.setDestinationIp(destIp);
        entry.setEventType(eventType);
        entry.setUser(user);
        entry.setPort(port);
        entry.setProcess(process);
        entry.setCommandLine(commandLine);
        entry.setMessage(message);
        entry.setSource("mock-generator");
        entry.setRawLog(JsonUtil.toPrettyJson(dto));
        return entry;
    }

    private String randomOf(String... options) {
        return options[random.nextInt(options.length)];
    }

    private Integer randomOf(int... options) {
        return options[random.nextInt(options.length)];
    }
}
