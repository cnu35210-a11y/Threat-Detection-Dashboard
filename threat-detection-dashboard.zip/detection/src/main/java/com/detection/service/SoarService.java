package com.detection.service;

import com.detection.model.LogEntry;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * Simula la capa de automatizacion y respuesta (Mini-SOAR: Security
 * Orchestration, Automation and Response) del dashboard.
 * <p>
 * No ejecuta ninguna accion real sobre la red: genera, a modo de simulacion,
 * la secuencia de pasos y el comando de firewall equivalente que un SOC
 * real ejecutaria para contener una alerta critica, y devuelve esas lineas
 * para mostrarlas en la consola de eventos de la UI.
 */
public class SoarService {

    private static final DateTimeFormatter LOG_TIME = DateTimeFormatter.ofPattern("HH:mm:ss");

    /**
     * Ejecuta (de forma simulada) el playbook de contencion de red para una
     * alerta dada, y marca el {@link LogEntry} como {@code CONTAINED}.
     *
     * @param alert alerta de severidad HIGH sobre la que se actua
     * @return lineas de consola que documentan cada paso simulado
     */
    public List<String> executeContainmentPlaybook(LogEntry alert) {
        List<String> lines = new ArrayList<>();
        String ip = alert.getSourceIp();
        String now = java.time.LocalTime.now().format(LOG_TIME);

        lines.add(prefix(now) + "Iniciando Playbook de Contencion para alerta #" + alert.getId()
                + " [" + alert.getRuleMatched() + "]");
        lines.add(prefix(now) + "Regla disparada: " + alert.getRuleMatched()
                + " | Tecnica MITRE: " + alert.getMitreId() + " - " + alert.getMitreTechnique());
        lines.add(prefix(now) + "Generando regla de firewall equivalente (simulado):");
        lines.add("            iptables -A INPUT -s " + ip + " -j DROP");
        lines.add("            netsh advfirewall firewall add rule name=\"BLOCK_" + ip
                + "\" dir=in action=block remoteip=" + ip);
        lines.add(prefix(now) + "Aislando host/IP origen en VLAN de cuarentena (simulado)...");
        lines.add(prefix(now) + "Terminando procesos asociados y revocando sesiones activas del usuario '"
                + alert.getUser() + "' (simulado)...");
        lines.add(prefix(now) + "Notificando al equipo SOC via webhook / ticket de incidente (simulado)...");
        lines.add(prefix(now) + "Estado del incidente #" + alert.getId() + " actualizado a: CONTAINED");

        alert.setStatus("CONTAINED");
        return lines;
    }

    private String prefix(String time) {
        return "[" + time + "] [SOAR] ";
    }
}
