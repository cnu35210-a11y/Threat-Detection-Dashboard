package com.detection.service.rule;

import com.detection.model.DetectionRule;
import com.detection.model.LogEntry;
import com.detection.model.Severity;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Regla de correlacion inspirada en una regla Sigma classica de deteccion de
 * fuerza bruta:
 * <pre>
 *   condition: eventType == authentication_failure
 *              AND count(sourceIp) >= 5
 *              AND timeframe &lt;= 10s
 * </pre>
 * Se dispara cuando existen 5 o mas fallos de autenticacion desde la misma
 * IP origen en una ventana movil de 10 segundos.
 */
public class BruteForceSshRule implements DetectionRule {

    private static final int THRESHOLD = 5;
    private static final Duration WINDOW = Duration.ofSeconds(10);

    @Override
    public String getId() { return "BF-SSH-001"; }

    @Override
    public String getName() { return "SSH Brute Force"; }

    @Override
    public Severity getSeverity() { return Severity.HIGH; }

    @Override
    public String getMitreId() { return "T1110"; }

    @Override
    public String getMitreTechnique() { return "Brute Force"; }

    @Override
    public String getDescription() {
        return "Se detectaron " + THRESHOLD + " o mas intentos fallidos de autenticacion SSH "
                + "desde la misma direccion IP origen en una ventana de " + WINDOW.getSeconds()
                + " segundos. Este patron es caracteristico de un ataque automatizado de "
                + "fuerza bruta (diccionario o credential stuffing) contra el servicio SSH.";
    }

    @Override
    public boolean evaluate(LogEntry current, List<LogEntry> history) {
        if (!"authentication_failure".equalsIgnoreCase(current.getEventType())) {
            return false;
        }
        LocalDateTime currentTime = current.getTimestamp();
        String sourceIp = current.getSourceIp();
        if (currentTime == null || sourceIp == null) {
            return false;
        }

        long matchingCount = history.stream()
                .filter(log -> sourceIp.equals(log.getSourceIp()))
                .filter(log -> "authentication_failure".equalsIgnoreCase(log.getEventType()))
                .filter(log -> log.getTimestamp() != null)
                .filter(log -> !log.getTimestamp().isBefore(currentTime.minus(WINDOW)))
                .filter(log -> !log.getTimestamp().isAfter(currentTime))
                .count();

        return matchingCount >= THRESHOLD;
    }
}
