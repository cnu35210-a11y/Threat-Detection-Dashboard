package com.detection.service.rule;

import com.detection.model.DetectionRule;
import com.detection.model.LogEntry;
import com.detection.model.Severity;

import java.util.List;

/**
 * Regla de deteccion de PowerShell ofuscado/codificado en base64, tecnica
 * comun para evadir controles de seguridad basados en firmas y para
 * descargar/ejecutar payloads de segunda etapa.
 */
public class EncodedPowerShellRule implements DetectionRule {

    @Override
    public String getId() { return "EXEC-PS-001"; }

    @Override
    public String getName() { return "Suspicious Encoded PowerShell"; }

    @Override
    public Severity getSeverity() { return Severity.HIGH; }

    @Override
    public String getMitreId() { return "T1059.001"; }

    @Override
    public String getMitreTechnique() { return "Command and Scripting Interpreter: PowerShell"; }

    @Override
    public String getDescription() {
        return "Se ejecuto powershell.exe con un comando codificado en Base64 (-EncodedCommand / -enc), "
                + "una tecnica de ofuscacion habitual utilizada para evadir deteccion basada en firmas "
                + "y ejecutar payloads de segunda etapa descargados en memoria.";
    }

    @Override
    public boolean evaluate(LogEntry current, List<LogEntry> history) {
        if (!"process_creation".equalsIgnoreCase(current.getEventType())) {
            return false;
        }
        String process = current.getProcess() == null ? "" : current.getProcess().toLowerCase();
        String commandLine = current.getCommandLine() == null ? "" : current.getCommandLine().toLowerCase();

        boolean isPowerShell = process.contains("powershell");
        boolean isEncoded = commandLine.contains("-enc") || commandLine.contains("-encodedcommand")
                || commandLine.contains("-e ");

        return isPowerShell && isEncoded;
    }
}
