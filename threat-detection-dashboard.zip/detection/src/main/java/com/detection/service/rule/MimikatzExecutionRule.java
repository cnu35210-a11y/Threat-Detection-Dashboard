package com.detection.service.rule;

import com.detection.model.DetectionRule;
import com.detection.model.LogEntry;
import com.detection.model.Severity;

import java.util.List;

/**
 * Regla estilo Sigma para deteccion de ejecucion de Mimikatz, la herramienta
 * de post-explotacion mas comun para volcado de credenciales en memoria
 * (LSASS). Busca coincidencias en el nombre del proceso o en la linea de
 * comando, incluyendo alias/ofuscaciones habituales.
 */
public class MimikatzExecutionRule implements DetectionRule {

    private static final String[] INDICATORS = {
            "mimikatz", "sekurlsa", "lsadump", "kerberos::golden", "privilege::debug"
    };

    @Override
    public String getId() { return "CRED-DUMP-001"; }

    @Override
    public String getName() { return "Mimikatz Execution / Credential Dumping"; }

    @Override
    public Severity getSeverity() { return Severity.HIGH; }

    @Override
    public String getMitreId() { return "T1003"; }

    @Override
    public String getMitreTechnique() { return "OS Credential Dumping"; }

    @Override
    public String getDescription() {
        return "Se detecto la ejecucion de un proceso o linea de comando que contiene "
                + "indicadores asociados a Mimikatz u operaciones de volcado de credenciales "
                + "(LSASS, SAM, Kerberos tickets). Esta actividad es tipicamente posterior a un "
                + "compromiso inicial y precede a movimiento lateral o escalamiento de privilegios.";
    }

    @Override
    public boolean evaluate(LogEntry current, List<LogEntry> history) {
        if (!"process_creation".equalsIgnoreCase(current.getEventType())) {
            return false;
        }
        String process = safeLower(current.getProcess());
        String commandLine = safeLower(current.getCommandLine());

        for (String indicator : INDICATORS) {
            if (process.contains(indicator) || commandLine.contains(indicator)) {
                return true;
            }
        }
        return false;
    }

    private String safeLower(String value) {
        return value == null ? "" : value.toLowerCase();
    }
}
