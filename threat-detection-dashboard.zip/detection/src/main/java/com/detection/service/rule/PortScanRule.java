package com.detection.service.rule;

import com.detection.model.DetectionRule;
import com.detection.model.LogEntry;
import com.detection.model.Severity;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Regla de correlacion para deteccion de escaneo de puertos (reconocimiento
 * de red): se dispara cuando la misma IP origen intenta conexiones contra 6
 * o mas puertos de destino distintos en una ventana de 15 segundos.
 */
public class PortScanRule implements DetectionRule {

    private static final int DISTINCT_PORT_THRESHOLD = 6;
    private static final Duration WINDOW = Duration.ofSeconds(15);

    @Override
    public String getId() { return "RECON-001"; }

    @Override
    public String getName() { return "Port Scan / Network Reconnaissance"; }

    @Override
    public Severity getSeverity() { return Severity.MEDIUM; }

    @Override
    public String getMitreId() { return "T1046"; }

    @Override
    public String getMitreTechnique() { return "Network Service Discovery"; }

    @Override
    public String getDescription() {
        return "La misma IP origen intento conexiones contra " + DISTINCT_PORT_THRESHOLD
                + " o mas puertos de destino distintos en una ventana de " + WINDOW.getSeconds()
                + " segundos, patron caracteristico de una fase de reconocimiento/escaneo de "
                + "red previa a la explotacion de un servicio expuesto.";
    }

    @Override
    public boolean evaluate(LogEntry current, List<LogEntry> history) {
        if (!isConnectionEvent(current.getEventType())) {
            return false;
        }
        LocalDateTime currentTime = current.getTimestamp();
        String sourceIp = current.getSourceIp();
        if (currentTime == null || sourceIp == null) {
            return false;
        }

        Set<Integer> distinctPorts = history.stream()
                .filter(log -> sourceIp.equals(log.getSourceIp()))
                .filter(log -> isConnectionEvent(log.getEventType()))
                .filter(log -> log.getTimestamp() != null)
                .filter(log -> !log.getTimestamp().isBefore(currentTime.minus(WINDOW)))
                .filter(log -> !log.getTimestamp().isAfter(currentTime))
                .map(LogEntry::getPort)
                .filter(port -> port != null)
                .collect(Collectors.toSet());

        return distinctPorts.size() >= DISTINCT_PORT_THRESHOLD;
    }

    private boolean isConnectionEvent(String eventType) {
        return "network_connection".equalsIgnoreCase(eventType)
                || "connection_attempt".equalsIgnoreCase(eventType);
    }
}
