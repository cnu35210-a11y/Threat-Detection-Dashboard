package com.detection.service.rule;

import com.detection.model.DetectionRule;
import com.detection.model.LogEntry;
import com.detection.model.Severity;

import java.util.List;

/**
 * Regla de deteccion de escalamiento de privilegios: cubre tanto eventos ya
 * clasificados explicitamente como {@code privilege_escalation} (ej. adicion
 * de un usuario a un grupo administrativo, Windows Event ID 4732/4728) como
 * el uso sospechoso de utilidades de elevacion (runas, sudo, su) hacia
 * cuentas de alto privilegio.
 */
public class PrivilegeEscalationRule implements DetectionRule {

    @Override
    public String getId() { return "PRIV-ESC-001"; }

    @Override
    public String getName() { return "Privilege Escalation"; }

    @Override
    public Severity getSeverity() { return Severity.HIGH; }

    @Override
    public String getMitreId() { return "T1068"; }

    @Override
    public String getMitreTechnique() { return "Exploitation for Privilege Escalation"; }

    @Override
    public String getDescription() {
        return "Se detecto un cambio de privilegios sospechoso: una cuenta fue agregada a un "
                + "grupo administrativo o se invoco una utilidad de elevacion (runas/sudo/su) "
                + "hacia una cuenta de alto privilegio (SYSTEM/root/Administrator). Este "
                + "comportamiento suele preceder a la toma de control total del host.";
    }

    @Override
    public boolean evaluate(LogEntry current, List<LogEntry> history) {
        if ("privilege_escalation".equalsIgnoreCase(current.getEventType())) {
            return true;
        }

        String message = safeLower(current.getMessage());
        if (message.contains("added to group administrators") || message.contains("added to group sudo")
                || message.contains("added to group wheel")) {
            return true;
        }

        if ("process_creation".equalsIgnoreCase(current.getEventType())) {
            String commandLine = safeLower(current.getCommandLine());
            boolean elevationTool = commandLine.contains("runas") || commandLine.startsWith("sudo")
                    || commandLine.contains(" su ") || commandLine.contains("su root");
            boolean targetsHighPrivilege = commandLine.contains("system") || commandLine.contains("root")
                    || commandLine.contains("administrator");
            return elevationTool && targetsHighPrivilege;
        }
        return false;
    }

    private String safeLower(String value) {
        return value == null ? "" : value.toLowerCase();
    }
}
