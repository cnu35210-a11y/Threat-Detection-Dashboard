package com.detection.util;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

/**
 * Punto unico de acceso al {@link ObjectMapper} de Jackson, configurado para
 * soportar {@code LocalDateTime} (via {@link JavaTimeModule}) y para ser
 * tolerante con campos desconocidos o ausentes en los logs de entrada.
 */
public final class JsonUtil {

    private static final ObjectMapper MAPPER = buildMapper();

    private JsonUtil() {
        // utilidad estatica, no instanciable
    }

    public static ObjectMapper mapper() {
        return MAPPER;
    }

    private static ObjectMapper buildMapper() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        mapper.enable(SerializationFeature.INDENT_OUTPUT);
        return mapper;
    }

    /** Serializa cualquier objeto a JSON indentado, usado para el panel de log crudo. */
    public static String toPrettyJson(Object value) {
        try {
            return MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(value);
        } catch (Exception e) {
            return "{\"error\": \"No se pudo serializar el log: " + e.getMessage() + "\"}";
        }
    }
}
